package cn.edu.thssdb.type;

public enum ExpressionType {
    NUMBER, STRING, COLUMN, NULL
}
