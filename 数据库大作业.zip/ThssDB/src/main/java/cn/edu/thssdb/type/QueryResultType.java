package cn.edu.thssdb.type;

public enum QueryResultType {
    SELECT, MESSAGE
}
