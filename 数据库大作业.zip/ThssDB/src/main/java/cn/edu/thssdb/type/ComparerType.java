package cn.edu.thssdb.type;

public enum ComparerType {
    NUMBER, STRING, NULL, COLUMN
}


